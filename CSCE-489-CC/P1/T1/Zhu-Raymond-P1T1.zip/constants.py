host = "34.233.78.56"
db = "fitness_923008555"
collection = "fitness_923008555"

