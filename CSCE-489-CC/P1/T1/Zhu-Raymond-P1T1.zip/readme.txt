Raymond Zhu
923008555

To run the script simply type "python queries.py" in the command line
If using compute or tamu servers, please use python3 in replacement of python

I modified the dummy-fitness.json by adding the initial data to the new given.
And so, the json file contains all 9 documents. 

I found on stackoverflow how to input a json file using pymongo. Url is as listed.
https://stackoverflow.com/questions/11568246/loading-several-text-files-into-mongodb-using-pymongo

