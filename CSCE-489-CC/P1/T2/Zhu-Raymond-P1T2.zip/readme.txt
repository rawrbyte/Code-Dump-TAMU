Open up a terminal to run ./redis-server and once the server is up and running
you can use any amount of new terminals to connect to server with the prototype. 

The python file can be run by typing

python message_board.py